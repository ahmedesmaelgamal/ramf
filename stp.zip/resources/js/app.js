import './bootstrap';
import Alpine from 'alpinejs';
// import '../css/custom.css';

window.Alpine = Alpine;
Alpine.start();
